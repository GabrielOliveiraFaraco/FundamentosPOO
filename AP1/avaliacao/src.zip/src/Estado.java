public class Estado {

    private String nome;

    public Estado(String nome){
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }
}
